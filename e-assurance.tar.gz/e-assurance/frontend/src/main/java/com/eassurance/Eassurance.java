package com.eassurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eassurance {

    public static void main(String[] args) {
        SpringApplication.run(Eassurance.class, args);
    }
}
